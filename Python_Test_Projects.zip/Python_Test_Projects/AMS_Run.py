import tkinter as tk
import pandas as pd
import datetime
import time
import csv
from PIL import Image, ImageTk
from tkinter import *
import cv2
import os
import numpy as np
from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from email import message
import tensorflow as tf
from PIL import Image
from numpy import asarray
from mtcnn.mtcnn import MTCNN
from keras.models import load_model,model_from_json
import smtplib,ssl
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from tkinter import messagebox
import pymysql.connections

# Defining the main Window of Smart Surveillance and attendance system 

window = tk.Tk()
window.title("Smart Surveillance & Attendance System")

window.geometry('1280x720')
window.configure(background='cyan')
window.resizable(False,False)


def attendance_manually():
    global stud_win
    stud_win = tk.Tk()
    # stud_win.iconbitmap('AMS.ico')
    stud_win.title("Enter subject name...")
    stud_win.geometry('580x320')
    stud_win.configure(background='grey80')

    def Field_error():

        def err_scr_delete():
            err_scr.destroy()
        global err_scr
        err_scr = tk.Tk()
        err_scr.geometry('300x100')
        # err_scr.iconbitmap('AMS.ico')
        err_scr.title('Warning!!')
        err_scr.configure(background='snow')
        Label(err_scr, text='Please enter your subject name!!!', fg='red',
              bg='white', font=('times', 16, ' bold ')).pack()
        Button(err_scr, text='OK', command=err_scr_delete, fg="black", bg="lawn green", width=9, height=1, activebackground="Red",
               font=('times', 15, ' bold ')).place(x=90, y=50)

    def fill_attendance():
        time_stamp = time.time()
        Date = datetime.datetime.fromtimestamp(time_stamp).strftime('%Y_%m_%d')
        timeStamp = datetime.datetime.fromtimestamp(time_stamp).strftime('%H:%M:%S')
        Time = datetime.datetime.fromtimestamp(time_stamp).strftime('%H:%M:%S')
        Hour, Minute, Second = timeStamp.split(":")
        # Creatting csv of attendance

        # Create table for Attendance
        date_for_DB = datetime.datetime.fromtimestamp(time_stamp).strftime('%Y_%m_%d')
        global subb
        subb = SUB_ENTRY.get()
        DB_table_name = str(subb + "_" + Date + "_Time_" +
                            Hour + "_" + Minute + "_" + Second)

        import pymysql.connections

        # Connect to the database
        try:
            global cursor
            connection = pymysql.connect(
                host='localhost', user='root', password='Temoor123', db='manually_fill_attendance')
            cursor = connection.cursor()
        except Exception as e:
            print(e)

        sql = "CREATE TABLE " + DB_table_name + """
                        (ID INT NOT NULL AUTO_INCREMENT,
                         ENROLLMENT varchar(100) NOT NULL,
                         NAME VARCHAR(50) NOT NULL,
                         DATE VARCHAR(20) NOT NULL,
                         TIME VARCHAR(20) NOT NULL,
                             PRIMARY KEY (ID)
                             );
                        """

        # Exception Handling for table creation
        try:
            
            cursor.execute(sql)  # SQL Command that help to create a table
        except Exception as ex:
            print(ex)  

        if subb == '':
            Field_error()
        else:
            stud_win.destroy()
            Manual_window = tk.Tk()
            # Manual_window.iconbitmap('AMS.ico')
            Manual_window.title("Student Attendance Manually " + str(subb))
            Manual_window.geometry('880x470')
            Manual_window.configure(background='grey80')

            def del_errsc2():
                error_window.destroy()

            def show_warning1():
                global error_window
                error_window = tk.Tk()
                error_window.geometry('330x100')
                # error_window.iconbitmap('AMS.ico')
                error_window.title('Warning!!')
                error_window.configure(background='grey80')
                Label(error_window, text='Please enter Student & Enrollment!!!', fg='black', bg='white',
                      font=('times', 16, ' bold ')).pack()
                Button(error_window, text='OK', command=del_errsc2, fg="black", bg="lawn green", width=9, height=1,
                       activebackground="Red", font=('times', 15, ' bold ')).place(x=90, y=50)

            def testVal(inStr, acttyp):
                if acttyp == '1':  # insert
                    if not inStr.isdigit():
                        return False
                return True

            stud_enrolment = tk.Label(Manual_window, text="Enter Enrollment", width=15, height=2, fg="black", bg="grey",
                           font=('times', 15))
            stud_enrolment.place(x=30, y=100)

            STU_NAME = tk.Label(Manual_window, text="Enter Student name", width=15, height=2, fg="black", bg="grey",
                                font=('times', 15))
            STU_NAME.place(x=30, y=200)

            global Stud_enrolment_entry
            Stud_enrolment_entry = tk.Entry(Manual_window, width=20, validate='key',
                                 bg="white", fg="black", font=('times', 23))
            Stud_enrolment_entry['validatecommand'] = (
                Stud_enrolment_entry.register(testVal), '%P', '%d')
            Stud_enrolment_entry.place(x=290, y=105)

            def remove_enr():
                Stud_enrolment_entry.delete(first=0, last=22)

            STUDENT_ENTRY = tk.Entry(Manual_window, width=20, bg="white", fg="black", font=('times', 23))


            STUDENT_ENTRY.place(x=290, y=205)

            def remove_student():
                STUDENT_ENTRY.delete(first=0, last=22)

            # get important variable
            def Insert_data_database():
                ENROLLMENT = Stud_enrolment_entry.get()
                STUDENT = STUDENT_ENTRY.get()
                if ENROLLMENT == '':
                    show_warning1()
                elif STUDENT == '':
                    show_warning1()
                else:
                    time = datetime.datetime.fromtimestamp(
                        time_stamp).strftime('%H:%M:%S')
                    Hour, Minute, Second = time.split(":")
                    Insert_data = "INSERT INTO " + DB_table_name + \
                        " (ID,ENROLLMENT,NAME,DATE,TIME) VALUES (0, %s, %s, %s,%s)"
                    VALUES = (str(ENROLLMENT), str(
                        STUDENT), str(Date), str(time))
                    try:
                        cursor.execute(Insert_data, VALUES)
                    except Exception as e:
                        print(e)
                    Stud_enrolment_entry.delete(first=0, last=22)
                    STUDENT_ENTRY.delete(first=0, last=22)

            def create_csv():
                import csv
                cursor.execute("select * from " + DB_table_name + ";")
                csv_name = 'C:/Users/pc/Documents/Python_Test_Projects/Attendance/Manually Attendance/'+DB_table_name+'.csv'
                with open(csv_name, "w") as csv_file:
                    csv_writer = csv.writer(csv_file)
                    csv_writer.writerow(
                        [i[0] for i in cursor.description])  # write headers
                    csv_writer.writerows(cursor)
                    O = "CSV created Successfully"
                    Notifi.configure(text=O, bg="Green", fg="white",
                                     width=33, font=('times', 19, 'bold'))
                    Notifi.place(x=180, y=380)
                import csv
                import tkinter
                root = tkinter.Tk()
                root.title("Attendance of " + subb)
                root.configure(background='grey80')
                with open(csv_name, newline="") as file:
                    reader = csv.reader(file)
                    r = 0

                    for col in reader:
                        c = 0
                        for row in col:
                            # i've added some styling
                            label = tkinter.Label(root, width=18, height=1, fg="black", font=('times', 13, ' bold '),
                                                  bg="white", text=row, relief=tkinter.RIDGE)
                            label.grid(row=r, column=c)
                            c += 1
                        r += 1
                root.mainloop()

            Notifi = tk.Label(Manual_window, text="CSV created Successfully", bg="Green", fg="white", width=33,
                              height=2, font=('times', 19, 'bold'))

            c1ear_enroll = tk.Button(Manual_window, text="Clear", command=remove_enr, fg="white", bg="black", width=10,
                                     height=1,
                                     activebackground="white", font=('times', 15, ' bold '))
            c1ear_enroll.place(x=690, y=100)

            c1ear_student = tk.Button(Manual_window, text="Clear", command=remove_student, fg="white", bg="black", width=10,
                                      height=1,
                                      activebackground="white", font=('times', 15, ' bold '))
            c1ear_student.place(x=690, y=200)

            DATA_SUB = tk.Button(Manual_window, text="Enter Data", command=Insert_data_database, fg="black", bg="SkyBlue1", width=20,
                                 height=2,
                                 activebackground="white", font=('times', 15, ' bold '))
            DATA_SUB.place(x=170, y=300)

            MAKE_CSV = tk.Button(Manual_window, text="Convert to CSV", command=create_csv, fg="black", bg="SkyBlue1", width=20,
                                 height=2,
                                 activebackground="white", font=('times', 15, ' bold '))
            MAKE_CSV.place(x=570, y=300)

            def attf():
                import subprocess
                subprocess.Popen(
                    r'explorer /select,"C:\Users\pc\Documents\Python_Test_Projects\Attendance\Manually Attendance\-------Check atttendance-------"')

            attf = tk.Button(Manual_window,  text="Check Sheets", command=attf, fg="white", bg="black",
                             width=12, height=1, activebackground="white", font=('times', 14, ' bold '))
            attf.place(x=730, y=410)

            Manual_window.mainloop()

    SUB = tk.Label(stud_win, text="Enter Subject : ", width=15, height=2,
                   fg="black", bg="grey80", font=('times', 15, ' bold '))
    SUB.place(x=30, y=100)

    global SUB_ENTRY

    SUB_ENTRY = tk.Entry(stud_win, width=20, bg="white",
                         fg="black", font=('times', 23))
    SUB_ENTRY.place(x=250, y=105)

    fill_manual_attendance = tk.Button(stud_win, text="Fill Attendance", command=fill_attendance, fg="black", bg="SkyBlue1", width=20, height=2,
                                       activebackground="white", font=('times', 15, ' bold '))
    fill_manual_attendance.place(x=250, y=160)
    stud_win.mainloop()

# For clear textbox


def clear():
    txt.delete(first=0, last=22)


def clear1():
    txt2.delete(first=0, last=22)


def del_sc1():
    sc1.destroy()


def show_warning():
    global sc1
    sc1 = tk.Tk()
    sc1.geometry('300x100')
    # sc1.iconbitmap('AMS.ico')
    sc1.title('Warning!!')
    sc1.configure(background='grey80')
    Label(sc1, text='Enrollment & Name required!!!', fg='black',
          bg='white', font=('times', 16)).pack()
    Button(sc1, text='OK', command=del_sc1, fg="black", bg="lawn green", width=9,
           height=1, activebackground="Red", font=('times', 15, ' bold ')).place(x=90, y=50)

# Error screen2


def del_sc2():
    sc2.destroy()


def show_warning1():
    global sc2
    sc2 = tk.Tk()
    sc2.geometry('300x100')
    # sc2.iconbitmap('AMS.ico')
    sc2.title('Warning!!')
    sc2.configure(background='grey80')
    Label(sc2, text='Please enter your subject name!!!', fg='black',
          bg='white', font=('times', 16)).pack()
    Button(sc2, text='OK', command=del_sc2, fg="black", bg="lawn green", width=9,
           height=1, activebackground="Red", font=('times', 15, ' bold ')).place(x=90, y=50)

# For take images for datasets


def take_img():
    l1 = txt.get()
    l2 = txt2.get()
    if l1 == '':
        show_warning()
    elif l2 == '':
        show_warning()
    else:
        try:
            cam = cv2.VideoCapture(0)
            detector = cv2.CascadeClassifier(
                'haarcascade_frontalface_default.xml')
            Enrollment = txt.get()
            Name = txt2.get()
            sampleNum = 0
            while (True):
                ret, img = cam.read()
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = detector.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    # incrementing sample number
                    sampleNum = sampleNum + 1
                    # saving the captured face in the dataset folder
                    cv2.imwrite("TrainingImage/ " + Name + "." + Enrollment + '.' + str(sampleNum) + ".jpg",
                                gray)
                    print("Images Saved for Enrollment :")
                    cv2.imshow('Frame', img)
                # wait for 100 miliseconds
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                #  break if the sample number is more than 100
                elif sampleNum > 100:
                    break


            cam.release()
            cv2.destroyAllWindows()
            time_stamp = time.time()
            Date = datetime.datetime.fromtimestamp(time_stamp).strftime('%Y-%m-%d')
            Time = datetime.datetime.fromtimestamp(time_stamp).strftime('%H:%M:%S')
            row = [Enrollment, Name, Date, Time]
            with open('StudentDetails\StudentDetails.csv', 'a+') as csvFile:
                writer = csv.writer(csvFile, delimiter=',')
                writer.writerow(row)
                csvFile.close()
            res = "Images Saved for Enrollment : " + Enrollment + " Name : " + Name
            Notification.configure(
                text=res, bg="SpringGreen3", width=50, font=('times', 18, 'bold'))
            Notification.place(x=250, y=400)
        except FileExistsError as F:
            f = 'Student Data already exists'
            Notification.configure(text=f, bg="Red", width=21)
            Notification.place(x=450, y=400)


# Here student can choose field and mark attendance
def Field():
    def Attendancemark():
        sub = tx.get()
        now = time.time()  # For calculate seconds of video
        future = now + 20
        if time.time() < future:
            if sub == '':
                show_warning1()
            else:
                recognizer = cv2.face.LBPHFaceRecognizer_create()  # cv2.createLBPHFaceRecognizer()
                try:
                    recognizer.read("TrainingImageLabel\Trainner.yml")
                except:
                    e = 'Model not found,Please train model'
                    Notifica.configure(
                        text=e, bg="red", fg="black", width=33, font=('times', 15, 'bold'))
                    Notifica.place(x=20, y=250)

                harcascadePath = "haarcascade_frontalface_default.xml"
                faceCascade = cv2.CascadeClassifier(harcascadePath)
                df = pd.read_csv("StudentDetails\StudentDetails.csv")
                cam = cv2.VideoCapture(0)
                font = cv2.FONT_HERSHEY_SIMPLEX
                col_names = ['Enrollment', 'Name', 'Date', 'Time']
                attendance = pd.DataFrame(columns=col_names)
                while True:
                    ret, im = cam.read()
                    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
                    faces = faceCascade.detectMultiScale(gray, 1.2, 5)
                    for (x, y, w, h) in faces:
                        global Id

                        Id, conf = recognizer.predict(gray[y:y + h, x:x + w])
                        if (conf < 70):
                            print(conf)
                            global Subject
                            global aa
                            global date
                            global timeStamp
                            Subject = tx.get()
                            time_stamp = time.time()
                            date = datetime.datetime.fromtimestamp(
                                time_stamp).strftime('%Y-%m-%d')
                            timeStamp = datetime.datetime.fromtimestamp(
                                time_stamp).strftime('%H:%M:%S')
                            aa = df.loc[df['Enrollment'] == Id]['Name'].values
                            global tt
                            tt = str(Id) + "-" + aa
                            En = '15624031' + str(Id)
                            attendance.loc[len(attendance)] = [
                                Id, aa, date, timeStamp]
                            cv2.rectangle(
                                im, (x, y), (x + w, y + h), (0, 260, 0), 7)
                            cv2.putText(im, str(tt), (x + h, y),
                                        font, 1, (255, 255, 0,), 4)

                        else:
                            Id = 'Unknown'
                            tt = str(Id)
                            cv2.rectangle(
                                im, (x, y), (x + w, y + h), (0, 25, 255), 7)
                            cv2.putText(im, str(tt), (x + h, y),
                                        font, 1, (0, 25, 255), 4)
                    if time.time() > future:
                        break

                    attendance = attendance.drop_duplicates(
                        ['Enrollment'], keep='first')
                    cv2.imshow('Filling attedance..', im)
                    key = cv2.waitKey(30) & 0xff
                    if key == 27:
                        break

                time_stamp = time.time()
                date = datetime.datetime.fromtimestamp(time_stamp).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(
                    time_stamp).strftime('%H:%M:%S')
                Hour, Minute, Second = timeStamp.split(":")
                fileName = "Attendance/" + Subject + "_" + date + \
                    "_" + Hour + "-" + Minute + "-" + Second + ".csv"
                attendance = attendance.drop_duplicates(
                    ['Enrollment'], keep='first')
                print(attendance)
                attendance.to_csv(fileName, index=False)

                # Create table for Attendance
                date_for_DB = datetime.datetime.fromtimestamp(
                    time_stamp).strftime('%Y_%m_%d')
                DB_Table_name = str(
                    Subject + "_" + date_for_DB + "_Time_" + Hour + "_" + Minute + "_" + Second)
                

                # Connect to the database
                try:
                    global cursor
                    connection = pymysql.connect(
                        host='localhost', user='root', password='Temoor123', db='face_reco_fill')
                    cursor = connection.cursor()
                except Exception as e:
                    print(e)

                sql = "CREATE TABLE " + DB_Table_name + """
                (ID INT NOT NULL AUTO_INCREMENT,
                 ENROLLMENT varchar(100) NOT NULL,
                 NAME VARCHAR(50) NOT NULL,
                 DATE VARCHAR(20) NOT NULL,
                 TIME VARCHAR(20) NOT NULL,
                     PRIMARY KEY (ID)
                     );
                """
                # Now enter attendance in Database
                insert_data = "INSERT INTO " + DB_Table_name + \
                    " (ID,ENROLLMENT,NAME,DATE,TIME) VALUES (0, %s, %s, %s,%s)"
                VALUES = (str(Id), str(aa), str(date), str(timeStamp))
                try:
                    cursor.execute(sql)  # for create a table
                    # For insert data into table
                    cursor.execute(insert_data, VALUES)
                except Exception as ex:
                    print(ex)  #

                M = 'Attendance filled Successfully'
                Notifica.configure(text=M, bg="Green", fg="white",
                                   width=33, font=('times', 15, 'bold'))
                Notifica.place(x=20, y=250)

                cam.release()
                cv2.destroyAllWindows()

                import csv
                import tkinter
                root = tkinter.Tk()
                root.title("Attendance of " + Subject)
                root.configure(background='grey80')
                cs = 'C:/Users/pc/Documents/Python_Test_Projects/' + fileName
                with open(cs, newline="") as file:
                    reader = csv.reader(file)
                    r = 0

                    for col in reader:
                        c = 0
                        for row in col:
                            # i've added some styling
                            label = tkinter.Label(root, width=10, height=1, fg="black", font=('times', 15, ' bold '),
                                                  bg="white", text=row, relief=tkinter.RIDGE)
                            label.grid(row=r, column=c)
                            c += 1
                        r += 1
                root.mainloop()
                print(attendance)

    # windo is frame for subject chooser
    windo = tk.Tk()
    # windo.iconbitmap('AMS.ico')
    windo.title("Enter subject name...")
    windo.geometry('580x320')
    windo.configure(background='grey80')
    Notifica = tk.Label(windo, text="Attendance filled Successfully", bg="Green", fg="white", width=33,
                        height=2, font=('times', 15, 'bold'))

    def Attf():
        import subprocess
        subprocess.Popen(
            r'explorer /select,"C:\Users\pc\Documents\Python_Test_Projects\Attendance\-------Check atttendance-------"')

    attf = tk.Button(windo,  text="Check Sheets", command=Attf, fg="white", bg="black",
                     width=12, height=1, activebackground="white", font=('times', 14, ' bold '))
    attf.place(x=430, y=255)

    sub = tk.Label(windo, text="Enter Subject : ", width=15, height=2,
                   fg="black", bg="grey", font=('times', 15, ' bold '))
    sub.place(x=30, y=100)

    tx = tk.Entry(windo, width=20, bg="white",
                  fg="black", font=('times', 23))
    tx.place(x=250, y=105)

    fill_a = tk.Button(windo, text="Fill Attendance", fg="white", command=Attendancemark, bg="SkyBlue1", width=20, height=2,
                       activebackground="white", font=('times', 15, ' bold '))
    fill_a.place(x=250, y=160)
    windo.mainloop()


def admin_panel():
    win = tk.Tk()
    win.title("LogIn")
    win.geometry('880x420')
    win.configure(background='grey80')

    def log_in():
        username = un_entr.get()
        password = pw_entr.get()

        if username == 'Temoor':
            if password == 'Temoor123':
                win.destroy()
                import csv
                import tkinter
                root = tkinter.Tk()
                root.title("Student Details")
                root.configure(background='grey80')

                cs = 'C:/Users/pc/Documents/Python_Test_Projects/StudentDetails/StudentDetails.csv'
                with open(cs, newline="") as file:
                    reader = csv.reader(file)
                    r = 0

                    for col in reader:
                        c = 0
                        for row in col:
                            # i've added some styling
                            label = tkinter.Label(root, width=10, height=1, fg="black", font=('times', 15, ' bold '),
                                                  bg="white", text=row, relief=tkinter.RIDGE)
                            label.grid(row=r, column=c)
                            c += 1
                        r += 1
                root.mainloop()
            else:
                valid = 'Incorrect ID or Password'
                Nt.configure(text=valid, bg="red", fg="white",
                             width=38, font=('times', 19, 'bold'))
                Nt.place(x=120, y=350)

        else:
            valid = 'Incorrect ID or Password'
            Nt.configure(text=valid, bg="red", fg="white",
                         width=38, font=('times', 19, 'bold'))
            Nt.place(x=120, y=350)

    Nt = tk.Label(win, text="Attendance filled Successfully", bg="Green", fg="white", width=40,
                  height=2, font=('times', 19, 'bold'))
    # Nt.place(x=120, y=350)

    un = tk.Label(win, text="Enter username : ", width=15, height=2, fg="black", bg="grey",
                  font=('times', 15, ' bold '))
    un.place(x=30, y=50)

    pw = tk.Label(win, text="Enter password : ", width=15, height=2, fg="black", bg="grey",
                  font=('times', 15, ' bold '))
    pw.place(x=30, y=150)

    def c00():
        un_entr.delete(first=0, last=22)

    un_entr = tk.Entry(win, width=20, bg="white", fg="black",
                       font=('times', 23))
    un_entr.place(x=290, y=55)

    def c11():
        pw_entr.delete(first=0, last=22)

    pw_entr = tk.Entry(win, width=20, show="*", bg="white",
                       fg="black", font=('times', 23))
    pw_entr.place(x=290, y=155)

    c0 = tk.Button(win, text="Clear", command=c00, fg="white", bg="black", width=10, height=1,
                   activebackground="white", font=('times', 15, ' bold '))
    c0.place(x=690, y=55)

    c1 = tk.Button(win, text="Clear", command=c11, fg="white", bg="black", width=10, height=1,
                   activebackground="white", font=('times', 15, ' bold '))
    c1.place(x=690, y=155)

    Login = tk.Button(win, text="LogIn", fg="black", bg="SkyBlue1", width=20,
                      height=2,
                      activebackground="Red", command=log_in, font=('times', 15, ' bold '))
    Login.place(x=290, y=250)
    win.mainloop()


# For train the model
def trainimg():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    global detector
    detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    try:
        global faces, Id
        faces, Id = getImagesAndLabels("TrainingImage")
    except Exception as e:
        l = 'please make "TrainingImage" folder & put Images'
        Notification.configure(text=l, bg="SpringGreen3",
                               width=50, font=('times', 18, 'bold'))
        Notification.place(x=350, y=400)

    recognizer.train(faces, np.array(Id))
    try:
        recognizer.save("TrainingImageLabel\Trainner.yml")
    except Exception as e:
        q = 'Please make "TrainingImageLabel" folder'
        Notification.configure(text=q, bg="SpringGreen3",
                               width=50, font=('times', 18, 'bold'))
        Notification.place(x=350, y=400)

    res = "Model Trained"  # +",".join(str(f) for f in Id)
    Notification.configure(text=res, bg="olive drab",
                           width=50, font=('times', 18, 'bold'))
    Notification.place(x=250, y=400)

def recognition():
    rec_win = tk.Tk()
    rec_win.title("Email LogIn")
    rec_win.geometry('880x420')
    rec_win.configure(background='grey80')

    def logged_in():
       
        user_email = email_entr.get()
        user_pass = upass_entr.get()

        
        
        #Load pretrained Inception-ResNet-v1 model
        #Update model and weights path according to your working environment
        model_path = "Models/Inception_ResNet_v1.json"
        weights_path = "Models/facenet_keras.h5"

        json_file = open(model_path, 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        enc_model = model_from_json(loaded_model_json)
        enc_model.load_weights(weights_path)

        # Initialize a MTCNN face detector

        mtcnn_detector = MTCNN()

        # Function to detect and extract face from a image
        def detect_face(filename, required_size=(160, 160),normalize = True):

            img = Image.open(filename)

            # convert to RGB
            img = img.convert('RGB')
        
            # convert to array
            pixels = np.asarray(img)
        
            # detect faces in the image
            results = mtcnn_detector.detect_faces(pixels)
        
            # extract the bounding box from the first face
            x1, y1, width, height = results[0]['box']

            x1, y1 = abs(x1), abs(y1)
            x2, y2 = x1 + width, y1 + height

            # extract the face
            face = pixels[y1:y2, x1:x2]
        
            # resize pixels to the model size
            image = Image.fromarray(face)
            image = image.resize(required_size)
            face_array = asarray(image)
        
            if normalize == True:
                

                mean = np.mean(face_array, axis=(0,1,2), keepdims=True)
                std = np.std(face_array, axis=(0,1,2), keepdims=True)
                std_adj = np.maximum(std, 1.0)
                return (face_array - mean) / std

            else : 
                return face_array
        # Compute Face encodings and load IDs of known persons
        # Update face database path according to your working environment

        known_faces_encodings = []
        known_faces_ids = []

        known_faces_path = "TrainingImage/"

        def SendMail(ImgFileName):

            with open(ImgFileName, 'rb') as f:
                img_data = f.read()
            msg = MIMEMultipart()
            msg['Subject'] = 'Alert! Someone has accessed an unauthorized area'
            msg['From'] = 'Temoor Waqar'
            msg['To'] = 'Te,ppr'
            text = MIMEText("Unknown Person Detected")
            msg.attach(text)
            image = MIMEImage(img_data, name=os.path.basename(ImgFileName))
            msg.attach(image)
            
            context=ssl.create_default_context()
            s =  smtplib.SMTP_SSL("smtp.gmail.com",465,context=context)
            s.login(user_email,user_pass)
            s.sendmail('temoor.waqar@gmail.com','temoor.bcskkf18@iba-suk.edu.pk', msg.as_string())
            s.quit()
            print("Mail Sended")
        for filename in os.listdir(known_faces_path):
  
        # Detect faces
            face = detect_face(known_faces_path+filename,normalize = True)

            # Compute face encodings

            feature_vector = enc_model.predict(face.reshape(1,160,160,3))
            feature_vector/= np.sqrt(np.sum(feature_vector**2))
            known_faces_encodings.append(feature_vector)

            # Save Person IDs
            label = filename.split('.')[0]
            known_faces_ids.append(label)

        known_faces_encodings = np.array(known_faces_encodings).reshape(len(known_faces_encodings),128)
        known_faces_ids = np.array(known_faces_ids)

        # No. of known IDs loaded from database

        print(known_faces_ids.shape[0])

        # Function to recognize a face (if it is in known_faces)

        def recognize(img,known_faces_encodings,known_faces_ids,threshold = 0.95):

            scores = np.zeros((len(known_faces_ids),1),dtype=float)

            enc = enc_model.predict(img.reshape(1,160,160,3))
            enc/= np.sqrt(np.sum(enc**2))

            scores = np.sqrt(np.sum((enc-known_faces_encodings)**2,axis=1))

            match = np.argmin(scores)

            if scores[match] > threshold:
                
                return ("UNKNOWN",0)
      
            else:
                starttime=0
                return (known_faces_ids[match],scores[match])
        def face_recognition(mode,file_path,known_faces_encodings,known_faces_ids,
                         detector = 'haar', threshold = 0.75):
            

            if detector == 'haar':

                # Load the cascade
                face_cascade = cv2.CascadeClassifier('Models/haarcascade_frontalface_default.xml')
            if mode == 'webcam':

                # To capture webcam feed. Change argument for differnt webcams
                cap = cv2.VideoCapture(0)

            
            
            starttime = time.time()
            while True:

                # Read the frame
                _, img = cap.read()

                # Stop if end of video file
                if _ == False:
                    break

                if detector == 'haar':
    
                    #Convert to grayscale
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

                    # Detect the faces
                    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

                elif detector == 'mtcnn':  

                    results = mtcnn_detector.detect_faces(img)

                    if(len(results)==0):
                        continue

                    faces = []
    
                    for i in range(len(results)):
                        
                        x,y,w,h = results[i]['box']
                        x, y = abs(x), abs(y)
                        faces.append([x,y,w,h])
                count=0
                for (x, y, w, h) in faces:
                    
                    image = Image.fromarray(img[y:y+h, x:x+w])
                    image = image.resize((160,160))
                    face_array = asarray(image)

                    # Normalize
                    mean = np.mean(face_array, axis=(0,1,2), keepdims=True)
                    std = np.std(face_array, axis=(0,1,2), keepdims=True)
                    std_adj = np.maximum(std, 1.0)
                    face_array_normalized = (face_array - mean) / std

                    # Recognize
                    
                    label = recognize(face_array_normalized,known_faces_encodings,known_faces_ids,threshold = 0.95)
                    if(label[0]=='UNKNOWN'):
                        endtime = time.time()
                        if(endtime-starttime>=5):
       
                            cv2.imwrite(str(count) + ".jpg", img)
                            message = str(count) + ".jpg"
                            SendMail(message)
                            print('Mail Sent')
                            starttime = time.time()
                            endtime = time.time
                        else:
                            starttime=time.time()
                            endtime=time.time()
                    
        
                             
                    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 0, 0), 2)
                    cv2.putText(img, label[0], (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255,255,255), 2)
                cv2.imshow('Face_Recognition', img)
    
                # Stop if escape key is pressed
                key = cv2.waitKey(25) & 0xff
                if key==27:
                    break
            # Release the VideoCapture object
            cap.release() 
        face_recognition('webcam',None,known_faces_encodings,known_faces_ids,
                 detector = 'mtcnn',threshold = 0.95)
        

    email = tk.Label(rec_win, text="Enter Email : ", width=15, height=2, fg="black", bg="grey",
                  font=('times', 15, ' bold '))
    email.place(x=30, y=50)

    upass = tk.Label(rec_win, text="Enter password : ", width=15, height=2, fg="black", bg="grey",
                  font=('times', 15, ' bold '))
    upass.place(x=30, y=150)

    def c00():
        email_entr.delete(first=0, last=22)

    email_entr = tk.Entry(rec_win, width=20, bg="white", fg="black",
                       font=('times', 23))
    email_entr.place(x=290, y=55)

    def c11():
        upass_entr.delete(first=0, last=22)

    upass_entr = tk.Entry(rec_win, width=20, show="*", bg="white",
                       fg="black", font=('times', 23))
    upass_entr.place(x=290, y=155)

    c0 = tk.Button(rec_win, text="Clear", command=c00, fg="white", bg="black", width=10, height=1,
                   activebackground="white", font=('times', 15, ' bold '))
    c0.place(x=690, y=55)

    c1 = tk.Button(rec_win, text="Clear", command=c11, fg="white", bg="black", width=10, height=1,
                   activebackground="white", font=('times', 15, ' bold '))
    c1.place(x=690, y=155)

    Login = tk.Button(rec_win, text="LogIn", fg="black", bg="SkyBlue1", width=20,
                      height=2,
                      activebackground="Red", command=logged_in, font=('times', 15, ' bold '))
    Login.place(x=290, y=250)
    rec_win.mainloop()


def developer():
    dev_win = tk.Toplevel()
    dev_win.title("Developer")
    dev_win.geometry('720x550')
    dev_win.configure(background='cyan')
    image1 = Image.open(r"C:\Users\pc\Documents\Python_Test_Projects\Images_GUI\Temoor.png")
    img = image1.resize((170, 200))

    test = ImageTk.PhotoImage(img)

    label1 = tk.Label(dev_win, image=test)
    label1.image = test

    # Position image
    label1.place(x=300, y=50)

    name = tk.Label(dev_win, text="Temoor Waqar", width=14, fg="black",
                bg="grey", height=2, font=('times', 15, ' bold '))
    name.place(x=300, y=252)

   
    
    
    
def getImagesAndLabels(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    # create empth face list
    faceSamples = []
    # create empty ID list
    Ids = []
    # now looping through all the image paths and loading the Ids and the images
    for imagePath in imagePaths:
        # loading the image and converting it to gray scale
        pilImage = Image.open(imagePath).convert('L')
        # Now we are converting the PIL image into numpy array
        imageNp = np.array(pilImage, 'uint8')
        # getting the Id from the image

        Id = int(os.path.split(imagePath)[-1].split(".")[1])
        # extract the face from the training image sample

        faces = detector.detectMultiScale(imageNp)
        # If a face is there then append that in the list as well as Id of it

        for (x, y, w, h) in faces:
            faceSamples.append(imageNp[y:y + h, x:x + w])
            Ids.append(Id)
    return faceSamples, Ids


window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)


def on_closing():
    
    if messagebox.askokcancel("Quit", "Do you want to quit?"):
        window.destroy()


window.protocol("WM_DELETE_WINDOW", on_closing)

message = tk.Label(window, text="Smart Surveillance and Attendance System", bg="Black", fg="cyan", width=50,
                   height=3, font=('times', 30, ' bold '))

message.place(x=30, y=20)

Notification = tk.Label(window, text="All things good", bg="Green", fg="white", width=15,
                        height=3, font=('times', 17))

lbl = tk.Label(window, text="Enter CMS ID ", width=20, height=2,
               fg="black", bg="cyan", font=('times', 15, 'bold'))
lbl.place(x=350, y=206)


def testVal(inStr, acttyp):
    if acttyp == '1':  # insert
        if not inStr.isdigit():
            return False
    return True


txt = tk.Entry(window, validate="key", width=20, bg="white",
               fg="black", font=('times', 25))
txt['validatecommand'] = (txt.register(testVal), '%P', '%d')
txt.place(x=550, y=210)

lbl2 = tk.Label(window, text="Enter Name ", width=20, fg="black",
                bg="cyan", height=2, font=('times', 15, ' bold '))
lbl2.place(x=350, y=310)

txt2 = tk.Entry(window, width=20, bg="white",
                fg="black", font=('times', 25))
txt2.place(x=550, y=310)



admin_pan = tk.Button(window, text="Records of Students", cursor="hand2", command=admin_panel, fg="black",
               bg="SkyBlue1", width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
admin_pan.place(x=90, y=620)



About_developer = tk.Button(window, text="Developer", cursor="hand2", command=developer, fg="black",
               bg="SkyBlue1", width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
About_developer.place(x=390, y=620)

takeImg = tk.Button(window, text="Create Dataset", cursor="hand2", command=take_img, fg="black", bg="SkyBlue1",
                    width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
takeImg.place(x=90, y=500)

trainImg = tk.Button(window, text="Train Model", cursor="hand2", fg="black", command=trainimg, bg="SkyBlue1",
                     width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
trainImg.place(x=390, y=500)


auto_attendance = tk.Button(window, text="Face Recognition", cursor="hand2", fg="black", command=Field,
               bg="SkyBlue1", width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
auto_attendance.place(x=690, y=500)

manual_attendance = tk.Button(window, text="Manually Fill Attendance", cursor="hand2", command=attendance_manually, fg="black",
                       bg="SkyBlue1", width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
manual_attendance.place(x=990, y=500)

exit = tk.Button(window, text="Exit", command=on_closing, cursor="hand2", fg="black",
                       bg="SkyBlue1", width=20, height=3, activebackground="white", font=('times', 15, ' bold '))
exit.place(x=690, y=620)

window.mainloop()
